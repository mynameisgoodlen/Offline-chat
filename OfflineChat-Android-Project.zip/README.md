# Offline Chat (Android)

A small one-to-one Android text chat prototype using Wi-Fi Direct. It sends messages directly between the two phones over the local Wi-Fi Direct group; it does not use an internet server, mobile data, or SMS. Emoji text is supported.

## Compatibility

- Minimum Android version: Android 6.0 (API 23)
- Supports Android 10 (API 29) and newer, including your POCO C3.
- The app contains Java/Android bytecode only and no native `.so` libraries or ABI filters. One APK is intended for both `armeabi-v7a` (32-bit) and `arm64-v8a` (64-bit) Android phones.

## Build the APK with GitHub Actions

1. Create a new GitHub repository and upload the contents of this folder (keep the hidden `.github/workflows/build.yml` file).
2. Open the repository's **Actions** tab.
3. Select **Build Offline Chat APK** and press **Run workflow**. A push to `main` or `master` also starts a build.
4. When the run finishes, open it and download the **Offline-Chat-APK** artifact. Extract `offline-chat.apk` and install it on both phones.

The workflow uses Java 17, Gradle 8.9, Android SDK 35, and Android Gradle Plugin 8.7.3. The Wi-Fi Direct enabled-state constant has been corrected, and the Android SDK setup action is v4.

## How to connect

1. Turn Wi-Fi on on both phones. You do not need to connect to a Wi-Fi router or enable mobile data.
2. On the first phone, open Offline Chat and tap **Create room**.
3. On the second phone, open Offline Chat and tap **Find friend**. On Android 10–12, grant Location permission and turn the Android Location toggle on if discovery asks for it. On Android 13 and newer, grant Nearby devices permission. These permissions are Android requirements for nearby Wi-Fi discovery; this app does not use GPS.
4. Tap the first phone in the nearby list. Accept any Android connection prompt.
5. Keep both phones and the app awake/open while chatting. Type a message or tap an emoji, then press **Send**.

## Important range limitation

Wi-Fi Direct is a nearby, phone-to-phone connection. This app cannot relay messages over the internet or through other people's phones. A reliable 1 km connection through buildings is not expected or guaranteed; actual range depends on phone models, interference, walls, and local conditions. The app must be tested at the intended locations before relying on it.

## Current prototype limitations

- One friend connection at a time.
- The app is designed to stay open in the foreground during a chat.
- Chat history is not saved after the app closes.
- No background delivery, push notifications, accounts, or internet fallback.
- This is a basic prototype, not an end-to-end encrypted messenger. Avoid sending sensitive information.
