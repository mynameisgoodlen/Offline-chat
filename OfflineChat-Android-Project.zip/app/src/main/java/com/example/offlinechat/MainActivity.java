package com.example.offlinechat;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.LocationManager;
import android.net.wifi.p2p.WifiP2pConfig;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pDeviceList;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.res.ColorStateList;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQUEST_PERMISSIONS = 410;
    private static final int CHAT_PORT = 8988;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService ioExecutor = Executors.newCachedThreadPool();
    private final Object outputLock = new Object();

    private WifiP2pManager wifiManager;
    private WifiP2pManager.Channel wifiChannel;
    private BroadcastReceiver receiver;
    private boolean receiverRegistered = false;

    private LinearLayout root;
    private LinearLayout peersContainer;
    private LinearLayout messagesContainer;
    private ScrollView messagesScroll;
    private TextView statusView;
    private EditText messageInput;
    private Button createRoomButton;
    private Button findButton;

    private volatile ServerSocket serverSocket;
    private volatile Socket chatSocket;
    private volatile DataOutputStream chatOutput;
    private volatile boolean connected = false;
    private volatile boolean serverStarted = false;
    private volatile boolean clientConnecting = false;
    private volatile boolean closing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFFF8FAFC);
        getWindow().setNavigationBarColor(0xFFF8FAFC);
        buildUi();

        wifiManager = (WifiP2pManager) getSystemService(Context.WIFI_P2P_SERVICE);
        if (wifiManager == null) {
            setStatus("This phone does not support Wi-Fi Direct.");
            disableConnectionButtons();
            return;
        }
        wifiChannel = wifiManager.initialize(this, getMainLooper(), () -> setStatus("Wi-Fi Direct channel lost. Reopen the app."));
        createReceiver();
        registerP2pReceiver();
        requestNeededPermissions();
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(12));
        root.setBackgroundColor(0xFFF8FAFC);
        setContentView(root);

        TextView title = new TextView(this);
        title.setText("Offline Chat  💬");
        title.setTextSize(25);
        title.setTextColor(0xFF0F172A);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("Direct phone-to-phone messages • No internet");
        subtitle.setTextSize(13);
        subtitle.setTextColor(0xFF64748B);
        LinearLayout.LayoutParams subtitleParams = matchWrap();
        subtitleParams.topMargin = dp(3);
        subtitleParams.bottomMargin = dp(12);
        root.addView(subtitle, subtitleParams);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        createRoomButton = makeButton("Create room", 0xFF2563EB);
        findButton = makeButton("Find friend", 0xFF0F766E);
        actions.addView(createRoomButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        LinearLayout.LayoutParams findParams = new LinearLayout.LayoutParams(0, dp(48), 1);
        findParams.leftMargin = dp(8);
        actions.addView(findButton, findParams);
        root.addView(actions, matchWrap());

        statusView = new TextView(this);
        statusView.setText("Turn on Wi-Fi, then create a room on one phone.");
        statusView.setTextColor(0xFF334155);
        statusView.setTextSize(13);
        statusView.setPadding(dp(12), dp(10), dp(12), dp(10));
        statusView.setBackground(roundRect(0xFFE2E8F0, 12));
        LinearLayout.LayoutParams statusParams = matchWrap();
        statusParams.topMargin = dp(10);
        statusParams.bottomMargin = dp(8);
        root.addView(statusView, statusParams);

        TextView nearbyLabel = new TextView(this);
        nearbyLabel.setText("NEARBY PHONES  ·  Tap your friend to connect");
        nearbyLabel.setTextColor(0xFF64748B);
        nearbyLabel.setTextSize(11);
        nearbyLabel.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams nearbyParams = matchWrap();
        nearbyParams.bottomMargin = dp(5);
        root.addView(nearbyLabel, nearbyParams);

        peersContainer = new LinearLayout(this);
        peersContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(peersContainer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        View divider = new View(this);
        divider.setBackgroundColor(0xFFE2E8F0);
        LinearLayout.LayoutParams dividerParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        dividerParams.topMargin = dp(8);
        dividerParams.bottomMargin = dp(8);
        root.addView(divider, dividerParams);

        messagesScroll = new ScrollView(this);
        messagesScroll.setFillViewport(true);
        messagesContainer = new LinearLayout(this);
        messagesContainer.setOrientation(LinearLayout.VERTICAL);
        messagesContainer.setPadding(dp(2), dp(4), dp(2), dp(8));
        messagesScroll.addView(messagesContainer, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(messagesScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        addSystemMessage("Messages will appear here once you connect.");

        LinearLayout emojiRow = new LinearLayout(this);
        emojiRow.setOrientation(LinearLayout.HORIZONTAL);
        String[] emojis = {"😀", "😂", "❤️", "👍", "🔥", "😭"};
        for (String emoji : emojis) {
            Button emojiButton = makeButton(emoji, 0xFFE2E8F0);
            emojiButton.setTextColor(0xFF0F172A);
            emojiButton.setTextSize(20);
            emojiButton.setMinWidth(0);
            emojiButton.setPadding(0, 0, 0, 0);
            LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(0, dp(42), 1);
            ep.leftMargin = dp(2);
            ep.rightMargin = dp(2);
            emojiRow.addView(emojiButton, ep);
            emojiButton.setOnClickListener(v -> messageInput.append(emoji));
        }
        LinearLayout.LayoutParams emojiParams = matchWrap();
        emojiParams.bottomMargin = dp(6);
        root.addView(emojiRow, emojiParams);

        LinearLayout composer = new LinearLayout(this);
        composer.setOrientation(LinearLayout.HORIZONTAL);
        messageInput = new EditText(this);
        messageInput.setSingleLine(true);
        messageInput.setTextSize(15);
        messageInput.setHint("Write a message...");
        messageInput.setPadding(dp(12), 0, dp(12), 0);
        messageInput.setBackground(roundRect(0xFFFFFFFF, 14));
        composer.addView(messageInput, new LinearLayout.LayoutParams(0, dp(50), 1));
        Button sendButton = makeButton("Send ➤", 0xFF2563EB);
        LinearLayout.LayoutParams sendParams = new LinearLayout.LayoutParams(dp(88), dp(50));
        sendParams.leftMargin = dp(8);
        composer.addView(sendButton, sendParams);
        root.addView(composer, matchWrap());
        sendButton.setOnClickListener(v -> sendMessage());

        createRoomButton.setOnClickListener(v -> createRoom());
        findButton.setOnClickListener(v -> findPeers());
    }

    private void createReceiver() {
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION.equals(action)) {
                    int state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1);
                    if (state == WifiP2P_ENABLED) setStatus("Wi-Fi Direct is on. Create a room or find your friend.");
                    else setStatus("Turn on Wi-Fi in Android settings.");
                } else if (WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION.equals(action)) {
                    requestPeers();
                } else if (WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION.equals(action)) {
                    if (wifiManager != null && hasPermissions()) {
                        wifiManager.requestConnectionInfo(wifiChannel, info -> handleConnectionInfo(info));
                    }
                }
            }
        };
    }

    private static final int WIFI_P2P_ENABLED = 2;

    private void registerP2pReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);
        filter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
        filter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
        filter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, filter);
        receiverRegistered = true;
    }

    private void requestNeededPermissions() {
        List<String> needed = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.NEARBY_WIFI_DEVICES);
            }
        } else if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (!needed.isEmpty()) requestPermissions(needed.toArray(new String[0]), REQUEST_PERMISSIONS);
    }

    private boolean hasPermissions() {
        if (Build.VERSION.SDK_INT >= 33) return checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            if (hasPermissions()) setStatus("Permission granted. Create a room on one phone, then find it on the other.");
            else setStatus("Nearby-device permission is needed for Wi-Fi Direct discovery.");
        }
    }

    private void createRoom() {
        if (!readyForP2p()) return;
        setStatus("Creating your room… keep this app open.");
        wifiManager.createGroup(wifiChannel, new WifiP2pManager.ActionListener() {
            @Override public void onSuccess() { setStatus("Room created. On your friend's phone, tap Find friend and select this phone."); }
            @Override public void onFailure(int reason) { setStatus("Couldn't create room (code " + reason + "). Turn Wi-Fi off and on, then try again."); }
        });
    }

    private void findPeers() {
        if (!readyForP2p()) return;
        if (Build.VERSION.SDK_INT < 33 && !isLocationEnabled()) {
            new AlertDialog.Builder(this)
                    .setTitle("Turn on Location")
                    .setMessage("Android requires Location to be turned on for nearby Wi-Fi Direct discovery. This app does not use GPS to chat.")
                    .setPositiveButton("Open settings", (d, w) -> startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)))
                    .setNegativeButton("Cancel", null).show();
            return;
        }
        peersContainer.removeAllViews();
        setStatus("Searching for nearby phones…");
        wifiManager.discoverPeers(wifiChannel, new WifiP2pManager.ActionListener() {
            @Override public void onSuccess() { setStatus("Searching… make sure your friend has created a room."); }
            @Override public void onFailure(int reason) { setStatus("Search failed (code " + reason + "). Keep Wi-Fi on and try again."); }
        });
    }

    private boolean readyForP2p() {
        if (!hasPermissions()) {
            requestNeededPermissions();
            setStatus("Allow Nearby devices permission, then try again.");
            return false;
        }
        if (wifiManager == null || wifiChannel == null) {
            setStatus("Wi-Fi Direct is not available on this phone.");
            return false;
        }
        return true;
    }

    private boolean isLocationEnabled() {
        try {
            LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (locationManager == null) return false;
            if (Build.VERSION.SDK_INT >= 28) return locationManager.isLocationEnabled();
            return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
                    || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        } catch (Exception ignored) { return true; }
    }

    private void requestPeers() {
        if (wifiManager == null || !hasPermissions()) return;
        wifiManager.requestPeers(wifiChannel, this::showPeers);
    }

    private void showPeers(WifiP2pDeviceList peerList) {
        peersContainer.removeAllViews();
        List<WifiP2pDevice> peers = new ArrayList<>(peerList.getDeviceList());
        if (peers.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No phones found yet. Tap Find friend again.");
            empty.setTextColor(0xFF64748B);
            empty.setTextSize(13);
            empty.setPadding(dp(8), dp(8), dp(8), dp(8));
            peersContainer.addView(empty);
            return;
        }
        for (WifiP2pDevice device : peers) {
            String label = (device.deviceName == null || device.deviceName.trim().isEmpty()) ? "Android phone" : device.deviceName;
            Button peerButton = makeButton("📱  " + label + "     Connect", 0xFFFFFFFF);
            peerButton.setTextColor(0xFF0F172A);
            peerButton.setTextSize(14);
            peerButton.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams p = matchWrap();
            p.bottomMargin = dp(5);
            peersContainer.addView(peerButton, p);
            peerButton.setOnClickListener(v -> connectToPeer(device));
        }
    }

    private void connectToPeer(WifiP2pDevice device) {
        if (!readyForP2p()) return;
        WifiP2pConfig config = new WifiP2pConfig();
        config.deviceAddress = device.deviceAddress;
        config.groupOwnerIntent = 0;
        setStatus("Connecting to " + device.deviceName + "…");
        wifiManager.connect(wifiChannel, config, new WifiP2pManager.ActionListener() {
            @Override public void onSuccess() { setStatus("Connection request sent. Accept it if Android asks."); }
            @Override public void onFailure(int reason) { setStatus("Couldn't connect (code " + reason + "). Try searching again."); }
        });
    }

    private void handleConnectionInfo(WifiP2pInfo info) {
        if (info == null || !info.groupFormed || info.groupOwnerAddress == null) return;
        if (info.isGroupOwner) startChatServer();
        else connectChatClient(info.groupOwnerAddress.getHostAddress());
    }

    private void startChatServer() {
        if (serverStarted || closing) return;
        serverStarted = true;
        setStatus("Phone connected. Waiting for chat link…");
        ioExecutor.execute(() -> {
            try {
                ServerSocket server = new ServerSocket(CHAT_PORT);
                serverSocket = server;
                Socket client = server.accept();
                setupChatSocket(client);
            } catch (IOException e) {
                if (!closing) mainHandler.post(() -> setStatus("Chat connection failed. Reopen the room and reconnect."));
            }
        });
    }

    private void connectChatClient(String hostAddress) {
        if (clientConnecting || connected || closing) return;
        clientConnecting = true;
        setStatus("Wi-Fi connected. Opening chat…");
        ioExecutor.execute(() -> {
            Socket client = new Socket();
            try {
                IOException lastError = null;
                for (int attempt = 0; attempt < 20 && !closing; attempt++) {
                    try {
                        client.connect(new InetSocketAddress(hostAddress, CHAT_PORT), 1200);
                        lastError = null;
                        break;
                    } catch (IOException e) {
                        lastError = e;
                        try { Thread.sleep(500); } catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); break; }
                    }
                }
                if (lastError != null) throw lastError;
                setupChatSocket(client);
            } catch (IOException e) {
                try { client.close(); } catch (IOException ignored) { }
                mainHandler.post(() -> setStatus("Couldn't open chat. On the other phone, keep the room open and reconnect."));
            } finally {
                clientConnecting = false;
            }
        });
    }

    private void setupChatSocket(Socket socket) {
        try {
            socket.setTcpNoDelay(true);
            chatSocket = socket;
            DataInputStream input = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
            chatOutput = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
            connected = true;
            mainHandler.post(() -> setStatus("Connected directly. You can send messages and emojis!"));
            while (!closing && !socket.isClosed()) {
                String message = input.readUTF();
                mainHandler.post(() -> addChatMessage("Friend", message, false));
            }
        } catch (IOException e) {
            if (!closing) mainHandler.post(() -> setStatus("Chat disconnected. Keep both phones nearby and reconnect."));
        } finally {
            connected = false;
            closeChatSocket();
        }
    }

    private void sendMessage() {
        String message = messageInput.getText().toString().trim();
        if (message.isEmpty()) return;
        if (!connected || chatOutput == null) {
            Toast.makeText(this, "Connect to your friend first.", Toast.LENGTH_SHORT).show();
            return;
        }
        messageInput.setText("");
        addChatMessage("You", message, true);
        ioExecutor.execute(() -> {
            try {
                synchronized (outputLock) {
                    if (chatOutput == null) throw new IOException("Chat is disconnected");
                    chatOutput.writeUTF(message);
                    chatOutput.flush();
                }
            } catch (IOException e) {
                mainHandler.post(() -> setStatus("Message could not be sent. The chat may have disconnected."));
            }
        });
        View focused = getCurrentFocus();
        if (focused != null) ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(focused.getWindowToken(), 0);
    }

    private void addChatMessage(String sender, String message, boolean mine) {
        TextView bubble = new TextView(this);
        bubble.setText(sender + "\n" + message);
        bubble.setTextSize(15);
        bubble.setTextColor(mine ? 0xFFFFFFFF : 0xFF0F172A);
        bubble.setPadding(dp(12), dp(8), dp(12), dp(8));
        bubble.setBackground(roundRect(mine ? 0xFF2563EB : 0xFFE2E8F0, 14));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.gravity = mine ? Gravity.END : Gravity.START;
        params.topMargin = dp(4);
        params.bottomMargin = dp(4);
        params.leftMargin = dp(28);
        params.rightMargin = dp(28);
        messagesContainer.addView(bubble, params);
        messagesScroll.post(() -> messagesScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void addSystemMessage(String text) {
        TextView line = new TextView(this);
        line.setText(text);
        line.setTextColor(0xFF64748B);
        line.setTextSize(13);
        line.setGravity(Gravity.CENTER);
        line.setPadding(dp(8), dp(10), dp(8), dp(10));
        messagesContainer.addView(line, matchWrap());
    }

    private void setStatus(String text) {
        if (statusView != null) statusView.setText(text);
    }

    private void disableConnectionButtons() {
        if (createRoomButton != null) createRoomButton.setEnabled(false);
        if (findButton != null) findButton.setEnabled(false);
    }

    private Button makeButton(String text, int backgroundColor) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setTextColor(backgroundColor == 0xFFFFFFFF || backgroundColor == 0xFFE2E8F0 ? 0xFF0F172A : 0xFFFFFFFF);
        button.setBackground(roundRect(backgroundColor, 14));
        button.setPadding(dp(8), 0, dp(8), 0);
        return button;
    }

    private GradientDrawable roundRect(int color, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void closeChatSocket() {
        try { if (chatSocket != null) chatSocket.close(); } catch (IOException ignored) { }
        chatSocket = null;
        synchronized (outputLock) { chatOutput = null; }
    }

    @Override
    protected void onDestroy() {
        closing = true;
        closeChatSocket();
        try { if (serverSocket != null) serverSocket.close(); } catch (IOException ignored) { }
        if (receiverRegistered) {
            try { unregisterReceiver(receiver); } catch (Exception ignored) { }
            receiverRegistered = false;
        }
        ioExecutor.shutdownNow();
        super.onDestroy();
    }
}
